<?php include $header; ?>

<div id="master">
    <div id="main-container">

        <h2>User</h2>
        <br />
        <div id="nav-container-left">
            <!-- display a list of categories -->
            <ul>
                <p><a href="?action=show_add_form">Add a User</a>
                    <br></br>
                    <br></br>
                    <br></br>                
                    <br></br>
                    <br></br>
                    <br></br>
            </ul>
        </div>
        <div id ="content">

            <table border="1">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Password</th>
                        <th>Last Name</th>
                        <th>First Name</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $row_count = $users->num_rows;

                    for ($i = 0; $i < $row_count; $i++) :
                        $user = $users->fetch_assoc();
                        //$user_role = get_user_role($user['EmpRoleID']);
                 
                        ?>

                        <tr>
                            <td><?php echo $user['UserID']; ?></td>
                            <td><?php echo $user['Password']; ?></td>
                            <td><?php echo $user['UserLName']; ?></td>
                            <td><?php echo $user['UserFName']; ?></td>
                            <!--<td><?php echo $user_role['RoleDesc']; ?></td>-->

                            <td><form action="." method="post">
                                    <input type="hidden" name="action"
                                           value="show_edit_form" />
                                    <input type="hidden" name="user_id"
                                           value="<?php echo $user['UserID']; ?>" />
                                    <input type="submit" value="Edit" />
                                </form></td>

                            <td><form action="." method="post">
                                    <input type="hidden" name="action"
                                           value="delete_user" />
                                    <input type="hidden" name="UserID"
                                           value="<?php echo $user['UserID']; ?>" />
                                    <input type="submit" value="Delete" />
                                </form></td>
                        </tr>
                        <?php
                    endfor;
                    ?>

                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include $footer; ?>

