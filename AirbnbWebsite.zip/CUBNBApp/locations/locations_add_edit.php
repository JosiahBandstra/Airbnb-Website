<?php
require('../model/variables.php');
require('../model/config.php');
require('../model/cubnb_db.php');
$loc_count = get_loc_count();
if (isset($_POST['Loc_ID']) && isset($_POST['Loc_Description']) && isset($_POST['Loc_Address']) && isset($_POST['Loc_Rate']) && isset($_POST['Loc_Type']) && isset($_POST['Loc_Status']))
{
    $Loc_ID = $_POST['Loc_ID'];
    $Loc_Description = $_POST['Loc_Description'];
    $Loc_Address = $_POST['Loc_Address'];
    $Loc_Rate = $_POST['Loc_Rate'];
    $Loc_Type = $_POST['Loc_Type'];
    $Loc_Status = $_POST['Loc_Status'];
    

    add_location($Loc_ID , $Loc_Description , $Loc_Address , $Loc_Rate, $Loc_Type, $Loc_Status);
    
    header("Location: http://localhost/CUBNBApp/locations/locations_list.php");
}
else 
{ 
    if (isset($_POST['Loc_ID']))
    {
       $location = get_location($_POST['Loc_ID']);

    }
    else 
    {
        $location = "";  
    }
}
include $header;
?>

<div id="master">
    <div id="main-container">

        <?php
        if ($location == '')
        {
            $heading_text = "Add Location";
        }
        else
        {
            $heading_text = "Edit Location";
        }
        ?>
        <h2>Locations - <?php echo $heading_text; ?></h2>
        <br />

        <div id="nav-container-left">
            <ul>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
            </ul>
        </div>
        <div id ="content">

            <form action="" method="post" id="add_edit_location_form">            

                <?php if ($location == '') : ?>
                    <input type="hidden" name="action" value="add_location" />
                <?php else: ?>
                    <input type="hidden" name="action" value="update_location" />
                    <input type="hidden" name="location_ID"
                           value="<?php echo $location['Loc_ID']; ?>" />
                       <?php endif; ?>

                <label for="Loc_ID">Location ID:</label>
                <input name ="Loc_ID" type="text" STYLE="background-color: white" 
                <?php if (!($location == "")): ?>
                           value="<?php echo $location['Loc_ID']; ?>" readonly="readonly" 
                       <?php endif; ?>
                       />
                <label>(white = req'd)</label>
                <br />
                
            <!--Breathe, if you are stressed out, take a second and breathe.-->

                <!-- SNAME -->
                <label for="Loc_Description">Location Description:</label>
                <input name ="Loc_Description" type="text" STYLE="background-color: white" 
                <?php if (!($location == "")): ?>
                           value="<?php echo $location['Loc_Description']; ?>" readonly="readonly" 
                       <?php endif; ?>
                       />
                <label>(white = req'd)</label>
                <br />
                
                <!-- RATING -->
                <label for="Loc_Address">Location Address:</label>
                <input name ="Loc_Address" type="text" STYLE="background-color: white" 
                <?php if (!($location == "")): ?>
                           value="<?php echo $location['Loc_Address']; ?>" readonly="readonly" 
                       <?php endif; ?>
                       />
                <label>(white = req'd)</label>
                <br />
                
                <!-- AGE -->
                <label for="Loc_Rate">Location Rate:</label>
                <input name ="Loc_Rate" type="text" STYLE="background-color: white" 
                <?php if (!($location == "")): ?>
                           value="<?php echo $location['Loc_Rate']; ?>" readonly="readonly" 
                       <?php endif; ?>
                       />
                <label>(white = req'd)</label>
                <br />
                
                <!-- TRAINEE -->
                <label for="Loc_Type">Location Type:</label>
                <input name ="Loc_Type" type="text" STYLE="background-color: white" 
                <?php if (!($location == "")): ?>
                           value="<?php echo $location['Loc_Type']; ?>" readonly="readonly" 
                       <?php endif; ?>
                       />
                <label>(white = req'd)</label>
                <br />
                
                <label for="Loc_Status">Location Status:</label>
                <input name ="Loc_Status" type="text" STYLE="background-color: white" 
                <?php if (!($location == "")): ?>
                           value="<?php echo $location['Loc_Status']; ?>" readonly="readonly" 
                       <?php endif; ?>
                       />
                <label>(white = req'd)</label>
                <br />
                
                <label>&nbsp;</label>
                <input type="submit" value="Add Location" />
                <a href="?action=display">Cancel</a>
                <br />  
                <br />
            <form/>
        </div>
    </div>

<?php include $footer; ?>
