<?php
require('../model/variables.php');
require('../model/config.php');
require('../model/cubnb_db.php');
include $header;
$locations = get_locations();
$location = '';
if (isset($_POST['Loc_ID']))
    {
       $location = delete_location($_POST['Loc_ID']);
       
        header("Location: http://localhost/CUBNBApp/locations/locations_list.php");
    }
?>

<div id="master">
    <div id="main-container">

        <h2>Locations</h2>
        <br />
        <div id="nav-container-left">
            <!-- display a list of categories -->
            <ul>
                <p><a href="locations_add_edit.php">Add a Location</a>
                    <br></br>
                    <br></br>
                    <br></br>                
                    <br></br>
                    <br></br>
                    <br></br>
            </ul>
        </div>
        <div id ="content">

            <table border="1">
                <thead>
                    <tr>
                        <th>Location ID</th>
                        <th>Location Description</th>
                        <th>Location Address</th>
                        <th>Location Rate</th>
                        <th>Location Type</th>
                        <th>Location Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $row_count = $locations->num_rows;

                    for ($i = 0; $i < $row_count; $i++) :
                        $location = $locations->fetch_assoc();
                        ?>
                        <tr>
                            <!--display reservation boat ID-->
                            <td><?php echo $location['Loc_ID']; ?></td>
                            <!--display reservation date-->
                            <td><?php echo $location['Loc_Description']; ?></td>
                            <!--display reservation date-->
                            <td><?php echo $location['Loc_Address']; ?></td>
                            <!--display reservation sailor ID-->
                            <td><?php echo $location['Loc_Rate']; ?></td>
                            <!--display reservation sailor ID-->
                            <td><?php echo $location['Loc_Type']; ?></td>
                             <!--display reservation sailor ID-->
                            <td><?php echo $location['Loc_Status']; ?></td>
                            <!--allow edit of reservation-->
                            <td><form action="locations_add_edit.php" method="post">
                                    <input type="hidden" name="action"
                                           value="show_edit_form" />
                                    <input type="hidden" name="Loc_ID"
                                           value="<?php echo $location['Loc_ID']; ?>" />
                                    <input type="submit" value="Edit" />
                                </form></td>

                            <td><form action="" method="post">
                                    <input type="hidden" name="action"
                                           value="delete_location" />
                                    <input type="hidden" name="Loc_ID"
                                           value="<?php echo $location['Loc_ID']; ?>" />
                                    <input type="submit" value="Delete" />
                                </form></td>
                        </tr>
                        <?php
                    endfor;
                    ?>

                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include $footer; ?>
