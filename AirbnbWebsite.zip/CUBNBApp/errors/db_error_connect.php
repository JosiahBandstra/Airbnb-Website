<?php include $header; ?>

<div id="content">
    <h1>Database Error</h1>
    <p>An error occurred connecting to the database.</p>
    <p>Error message: <?php echo $connection_error; ?></p>
</div>

<?php include $footer; ?>
