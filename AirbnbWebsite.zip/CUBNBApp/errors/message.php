<?php include $header; ?>
<div id = "master">
    <div id="main-container">
        <div id="content">
            <h2 class="top">Status</h2>
            <p><?php echo $message; ?></p>
            
            <p><a href="index.php">Back</a></p>
        </div>
    </div>
</div>
