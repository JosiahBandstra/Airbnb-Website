<!DOCTYPE html>
<html>
    <head>
        <title>CU BNB</title>
        <link rel="stylesheet" type="text/css"
              href="<?php echo "$home"; ?>main.css" />
    </head>

    <body>

        <div id="master">

            <h1>Cornerstone University BNB System
                <img 
                    border="0"
                    align="right"
                    margin="50"
                    src="<?php echo $logo; ?>"
                    alt="125_logo">
            </h1>
            <br></br>

            <div id="nav-container-top">
                <ul>
                    <li><a href="<?php echo $home; ?>">Home</a></li>
                    <li><a href="<?php echo $home; ?>reservations/index.php">Reservations</a></li>
                    <li><a href="<?php echo $home; ?>locations/">Locations</a></li>
                    <li><a href="<?php echo $home; ?>users/">Users</a></li>
                    <li><a href="http://www.google.com">Exit</a></li>
                </ul>
            </div><!-- end div nav-container-top -->
        </div><!-- end div master -->

