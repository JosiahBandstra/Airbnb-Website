<?php
    require('model/variables.php');
    require('model/config.php');
    require('model/cubnb_db.php');

session_start();

if (isset($_REQUEST['UserID']) && isset($_REQUEST['Password'])) {
    //set session variables
    $_SESSION['userid'] = $_REQUEST['UserID'];
    $_SESSION['password'] = $_REQUEST['Password'];

    $SQL = 'SELECT * FROM cubnb_user WHERE UserID = '
            . '"' . $_SESSION['userid'] . '"';

    $result = $db->query($SQL);
    $row_cnt = $result->num_rows;
    $result = mysqli_fetch_array($result);
    //var_dump($result);

    if ($row_cnt == 1) {
        //$checkpass = generateHash($_SESSION['password']);
        if (verify($_SESSION['password'],$result['Password'])) {

//        $_SESSION['role'] = $result[0]; // set user's role
//
//        switch ($_SESSION['role']) {
//            case 'ADMIN' :
//                //possibly re-direct user based on role
//                break;
//            case 'HOUSE' :
//                //possibly re-direct user based on role
//                break;
//        }
            $_SESSION['firstname'] = $result['UserFName'];
            header("Location: http://localhost/CUBNBApp/index.php");
        } else {
            //TERMINATE user's session if logon fails
            ?>
            echo "Invalid User ID and/or Password!" <br/>
            <?php
            unset($_SESSION['userid']);
            unset($_SESSION['password']);
            session_destroy();
        }
    } else {
        //TERMINATE user's session if logon fails
        ?>
        echo "Invalid User ID and/or Password!" <br/>
        <?php
        unset($_SESSION['userid']);
        unset($_SESSION['password']);
        session_destroy();
    }
}
?>

<body>

    <form name="logon" action="" method="GET">
        <fieldset>
            <legend><strong>User Logon</strong></legend></br>
            <div id ="fieldgrid">
                <div id="row">
                    <div id="fieldlabel"><label for="UserID"><strong>User ID</strong></label>
                    </div>
                    <div id="fieldcontent"><input type="text" name="UserID" value="" size="8" id="UserID" />
                    </div>
                </div>
                <div id="row">
                    <div id="fieldlabel"><label for="Password"><strong>Password</strong></label>
                    </div>
                    <div id="fieldcontent"><input type="password" name="Password" value="" size="20" id="Password" />
                    </div>
                </div>
            </div>
            </br>
            <div id="buttongrid">
                <div id="row">
                    <div id="buttoncell" align="right"><input type="submit" value="Logon" name="submit"/>			
                    </div>
                </div>
            </div>
        </fieldset>
    </form>
</body>

