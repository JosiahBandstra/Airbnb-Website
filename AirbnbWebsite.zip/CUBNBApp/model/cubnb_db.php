<?php
function get_reservations_by_date()
{
    global $db;
    $query = "SELECT * FROM reservation INNER JOIN location ON reservation.Loc_ID=location.Loc_ID ORDER BY Res_Begin";
    $result = $db->query($query);
    $error = "";

    if ($result == false)
    {
        $error = $db->error;
    }

    if ($error != null)
    {
        include('../errors/error.php');
        exit();
    }
    else
    {
        $reservations = $result;
        return $reservations;
    }
}

function get_locations()
{
//add code to populate locations for list box
    global $db;
    $query = "SELECT * FROM location";
    $result = $db->query($query);
    $error = "";

    if ($result == false)
    {
        $error = $db->error;
    }

    if ($error != null)
    {
        include('../errors/error.php');
        exit();
    }
    else
    {
        $sailors = $result;
        return $sailors;
    }
}

function get_reservation($Res_ID, $Res_Begin)
{
    global $db;
    $query = "SELECT * FROM reservation
              WHERE Res_Begin = '$Res_Begin'
              AND Res_ID = '$Res_ID'";

    $result = $db->query($query);
    $result = mysqli_fetch_array($result);
    //$result = $result->fetch_row();
    return $result;
}

function get_location($Loc_ID)
{
    global $db;
    $query = "SELECT * FROM location
              WHERE Loc_ID = '$Loc_ID'";
                  
    $result = $db->query($query);
    $result = mysqli_fetch_array($result);
    return $result;
}

function get_reservations_count_by_locations($Loc_ID)
{
    global $db;
    $query = "SELECT count(*) FROM reservation WHERE Loc_ID = '$Loc_ID'";
    $result = $db->query($query)->fetch_assoc()['count(*)'];
    return $result;
}

function add_reservations ($Res_ID, $Loc_ID, $Res_Begin, $Res_End)
{
//add code to insert reservation into DB
    global $db;
    $query = "INSERT INTO reservation (Res_ID, Loc_ID, Res_Begin, Res_End) VALUES ('$Res_ID', '$Loc_ID', '$Res_Begin', '$Res_End')";

    mysqli_query($db,$query);
}

function add_location($Loc_ID , $Loc_Description , $Loc_Address , $Loc_Rate, $Loc_Type, $Loc_Status)
{
//add code to insert sailor into DB
    global $db;
    $query = "INSERT INTO location (Loc_ID , Loc_Description , Loc_Address , Loc_Rate, Loc_Type, Loc_Status) VALUES ('$Loc_ID','$Loc_Description','$Loc_Address','$Loc_Rate','$Loc_Type','$Loc_Status')";
//    echo $query;
//    die;
    mysqli_query($db,$query);
}

function delete_reservation($Res_ID)
{
//add code to delete reservation
    global $db;
    $query = "DELETE FROM reservation
        WHERE Res_ID = '$Res_ID'";
    if(mysqli_query($db,$query)){
        echo "Records were deleted successfully.";
    } else{
        echo "ERROR: Records were not deleted successfully $query.".
    mysqli_error($db);
    }
}

function delete_location($Loc_ID)
{
//add code to delete location
    global $db;
    $query = "DELETE FROM location
        WHERE Loc_ID = '$Loc_ID'";
    if(mysqli_query($db,$query)){
        echo "Records were deleted successfully.";
    } else{
        echo "ERROR: Records were not deleted successfully $query.".
    mysqli_error($db);
    }
}

function update_reservation($Res_ID, $Loc_ID, $Res_Begin, $Res_End)
{
//add code to update reservation
    global $db;
    $query = "UPDATE reservation
        SET Loc_ID = '$Loc_ID', Res_Begin = '$Res_Begin', Res_End = '$Res_End'
        WHERE Res_ID = '$Res_ID'";
        
    try {
        mysqli_query($db,$query);
    } catch (PDOException $e) {
        $error = $e->getMessage();
        include ('../error/error.php');
    }
}

function update_location($Loc_ID , $Loc_Description , $Loc_Address , $Loc_Rate, $Loc_Type, $Loc_Status)
{
//add code to update location
    global $db;
    $query = "UPDATE location
        SET Loc_Description = '$Loc_Description', Loc_Address = '$Loc_Address', Loc_Rate = '$Loc_Rate', Loc_Type = '$Loc_Type', Loc_Status = '$Loc_Status'
        WHERE Loc_ID  = '$Loc_ID'";
    
    try {
        mysqli_query($db,$query);
    } catch (PDOException $e) {
        $error = $e->getMessage();
        include ('../error/error.php');

    }
}

function get_res_count()
{
    global $db;

    $query = 'SELECT * FROM reservation';

    //run the query and store the result in an object
    $result = $db->query($query);

    //find the number of resulting rows from the object
    $row_cnt = $result->num_rows;

    return $row_cnt;
}

function get_loc_count()
{
    global $db;

    $query = 'SELECT * FROM location';

    //run the query and store the result in an object
    $result = $db->query($query);

    //find the number of resulting rows from the object
    $row_cnt = $result->num_rows;

    return $row_cnt;
}
function get_employee_count() 
{
    global $db;
    $query = 'SELECT count(*) FROM employees';
    $result = $db->query($query)->fetch_assoc()['count(*)'];
    return $result;
}

function get_users() 
{
    global $db;
    $query = "SELECT * FROM cubnb_user ORDER BY UserLName";
    $result = $db->query($query);
    $error = "";

    if ($result == false) 
    {
        $error = $db->error;
    }

    if ($error != null) 
    {
        include('../errors/error.php');
        exit();
    } 
    else 
    {
        return $result;
    }
}
function get_user($UserID) 
{
    global $db;
    $query = "SELECT * FROM cubnb_user WHERE UserID = '$UserID'";
    $result = $db->query($query);
    $result = mysqli_fetch_array($result);
    return $result;
}
function get_employee_role($EmpRoleID) 
{
    global $db;
    $query = "SELECT * FROM employee_roles WHERE RoleID = '$EmpRoleID'";
    $result = $db->query($query);
    $result = mysqli_fetch_array($result);
    return $result;
}
function get_roles() 
{
    global $db;
    $query = "SELECT * FROM employee_roles ORDER BY RoleDesc";
    $result = $db->query($query);
    $error = "";

    if ($result == false) 
    {
        $error = $db->error;
    }

    if ($error != null) 
    {
        include('../errors/error.php');
        exit();
    } 
    else 
    {
        return $result;
    }
}
function add_user($UserID, $Password, $UserLName, $UserFName) 
{
    global $db;
    $encryptedPass = generateHash($PASS);
//    echo $encryptedPass;
//    die;   
    $query = "INSERT INTO cubnb_user values ('$UserID','$Password','$UserLName','$UserFName')";
    mysqli_query($db, $query);
}
function delete_user($UserID) 
{
    global $db;
    $query = "DELETE FROM cubnb_user WHERE UserID = '$UserID'";
    mysqli_query($db, $query);
}
function generateHash($password) 
{
    if (defined("CRYPT_BLOWFISH") && CRYPT_BLOWFISH) 
    {
        $salt = '$2y$11$' . substr(md5(uniqid(7, true)), 0, 22);
        return crypt($password, $salt);
    }
}
function verify($password, $hashedPassword) 
{
    return crypt($password, $hashedPassword) == $hashedPassword;
    //return $checkPassword == $storedPassword;
}