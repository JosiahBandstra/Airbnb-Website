<?php
define('PROJECT_ROOT', 'c:\xampp\htdocs\CUBNBApp');
define('WEB_ROOT', 'http://localhost/CUBNBApp/');
$header = PROJECT_ROOT . '\view\header.php';
$footer = PROJECT_ROOT . '\view\footer.php';
$home = WEB_ROOT; '/home/customer/www/josiahc.sgedu.site/public.html';
$logo = WEB_ROOT . 'images/cornerstone-university-logo-2.0.png'; //add image here
$background = WEB_ROOT . 'images/bnb-room.jpg';
$locations = WEB_ROOT . 'images/bnb-locations.jpg';
$reservations = WEB_ROOT . 'images/bnb-reservations.jpg';
$user = WEB_ROOT . 'images/bnb-user.jpg';
//$logo = WEB_ROOT . 'images/CU_logo.png';
?>
