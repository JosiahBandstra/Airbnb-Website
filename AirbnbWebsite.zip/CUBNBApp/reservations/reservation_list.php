<?php 
require('../model/variables.php');
require('../model/config.php');
require('../model/cubnb_db.php');
include $header;
$reservations = get_reservations_by_date();
$reservation = '';
if (isset($_POST['Res_ID']))
    {
       $reservation = delete_reservation($_POST['Res_ID']);
       
       header("Location: http://localhost/CUBNBApp/reservations/reservation_list.php");
    }
?>
<div id="master">
    <div id="main-container">

        <h2>Reservations by Date</h2>
        <br />
        <div id="nav-container-left">
            <!-- display a list of categories -->
            <ul>
                <p><a href="reservation_add_edit.php">Make a Reservation</a>
                    <br></br>
                    <br></br>
                    <br></br>                
                    <br></br>
                    <br></br>
                    <br></br>
            </ul>
        </div>
        <div id ="content">

            <table border="1">
                <thead>
                    <tr>
                        <th>Reservation ID</th>
                        <th>Reservation Begin Date</th>
                        <th>Reservation End Date</th>
                        <th>Location ID</th>
                        <th>Location Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $row_count = $reservations->num_rows;

                    for ($i = 0; $i < $row_count; $i++) :
                        $reservation = $reservations->fetch_assoc();
                        
                        ?>
                        <tr>
                            <!--display reservation boat ID-->
                            <td><?php echo $reservation['Res_ID']; ?></td>
                            <!--display reservation date-->
                            <td><?php echo $reservation['Res_Begin']; ?></td>
                            <!--display reservation date-->
                            <td><?php echo $reservation['Res_End']; ?></td>
                            <!--display reservation sailor ID-->
                            <td><?php echo $reservation['Loc_ID']; ?></td>
                            <?php $location = get_location($reservation['Loc_ID']);?>
                            <td><?php echo $location['Loc_Description']; ?></td>
                            <!--allow edit of reservation-->
                            <td><form action="reservation_add_edit.php" method="post">
                                    <input type="hidden" name="action"
                                           value="show_edit_form" />
                                    <input type="hidden" name="Res_ID"
                                           value="<?php echo $reservation['Res_ID']; ?>" />
                                    <input type="hidden" name="Res_Begin"
                                           value="<?php echo $reservation['Res_Begin']; ?>" />
                                    <input type="submit" value="Edit" />
                                </form></td>

                            <td><form action="" method="post">
                                    <input type="hidden" name="action"
                                           value="delete_reservation" />
                                    <input type="hidden" name="Res_ID"
                                           value="<?php echo $reservation['Res_ID']; ?>" />
                                    <input type="hidden" name="Res_Begin"
                                           value="<?php echo $reservation['Res_Begin']; ?>" />
                                    <input type="submit" value="Delete" />
                                </form></td>
                        </tr>
                        <?php
                    endfor;
                    ?>

                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include $footer; ?>

