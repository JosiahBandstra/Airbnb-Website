<?php
require('../model/variables.php');
require('../model/config.php');
require('../model/cubnb_db.php');
$res_count = get_res_count();
$locations = get_locations();
//echo $_POST['Res_ID'];
//echo     $_POST['Loc_ID'];
//echo     $_POST['Res_Begin'];
//echo   $_POST['Res_End'];  
//     die;
if (isset($_POST['Res_ID']) && isset($_POST['Loc_ID']) && isset($_POST['Res_Begin']) && isset($_POST['Res_End']))
{
    $Res_ID = $_POST['Res_ID'];
    $Loc_ID = $_POST['Loc_ID'];
    $Res_Begin = $_POST['Res_Begin'];
    $Res_End = $_POST['Res_End'];    
    
    add_reservations ($Res_ID, $Loc_ID, $Res_Begin, $Res_End);
    
    header("Location: http://localhost/CUBNBApp/reservations/reservation_list.php");
}
else 
{ 
    if (isset($_POST['Res_ID']))
    {
       $reservation = get_reservation($_POST['Res_ID']);

    }
    else 
    {
        $reservation = "";  
    }
}
include $header;
?>

<div id="master">
    <div id="main-container">

        <?php
        if ($reservation == '')
        {
            $heading_text = "Add Reservation";
        }
        else
        {
            $heading_text = "Edit Reservation";
        }
        ?>
        <h2>Reservations - <?php echo $heading_text; ?></h2>
        <br />

        <div id="nav-container-left">
            <ul>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
            </ul>
        </div>
        <div id ="content">

            <form action="" method="post" id="add_edit_reservation_form">            

                <?php if ($reservation == '') : ?>
                    <input type="hidden" name="action" value="add_reservation" />
                <?php else: ?>
                    <input type="hidden" name="action" value="update_reservation" />
                    <input type="hidden" name="Res_ID"
                           value="<?php echo $reservation['Res_ID']; ?>" />
                    <input type="hidden" name="Res_Begin"
                           value="<?php echo $reservation['Res_Begin']; ?>" />
                       <?php endif; ?>

                <label for="Res_ID">Reservation ID:</label>
                <input name ="Res_ID" type="text" STYLE="background-color: white" 
                <?php if (!($reservation == "")): ?>
                           value="<?php echo $reservation['Res_ID']; ?>" readonly="readonly" 
                       <?php endif; ?>
                       />
                <label>(white = req'd)</label>
                <br />

                <label for="Loc_ID">Location ID:</label>
                <select name="Loc_ID">
                    <?php
                    $row_count = $locations->num_rows;

                    for ($i = 0; $i < $row_count; $i++) :
                        $location = $locations->fetch_assoc();
                        ?>

                        <option value="<?php echo $location['Loc_ID']; ?>"
                        <?php if (!($reservation == "") && $location['Loc_ID'] == $reservation['Loc_ID']):
                            echo "selected ";
                            ?> 
                                    <?php endif; ?>><?php
                                    echo $location['Loc_Description']; ?>
                                    </option>

                                    <?php
                                endfor;
                                ?>
                </select>
                <br />
                
                <?php
                date_default_timezone_set('EST');
                $defaultDate = date('m/d/Y');
                ?>
                <label for="Res_Begin">Reservation Begin Date:</label>
                <input name ="Res_Begin" type="date" STYLE="background-color: white" 
                <?php if ($reservation == ""): ?>
                    value="<?php echo $defaultDate; ?>"                             <?php else: ?>
                    value="<?php echo $reservation['Res_Begin']; ?>" readonly="readonly"
                <?php endif; ?>
                 />
                <label>("MM/DD/YYYY")</label>
                <br />
                
                <?php
                date_default_timezone_set('EST');
                $defaultDate = date('m/d/Y');
                ?>
                <label for="Res_End">Reservation End Date:</label>
                <input name ="Res_End" type="date" STYLE="background-color: white" 
                <?php if ($reservation == ""): ?>
                    value="<?php echo $defaultDate; ?>"                             <?php else: ?>
                    value="<?php echo $reservation['Res_End']; ?>" readonly="readonly"
                <?php endif; ?>
                 />
                <label>("MM/DD/YYYY")</label>
                <br />

                <label>&nbsp;</label>
                <input type="submit" value="Make Reservation" />
                <a href="?action=display">Cancel</a>
                <br />  
                <br />
            <form/>
        </div>
    </div>

<?php include $footer; ?>