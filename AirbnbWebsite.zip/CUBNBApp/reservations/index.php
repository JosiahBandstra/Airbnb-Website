<?php
require('../model/variables.php');
require('../model/config.php');
require('../model/cubnb_db.php');
$res_count = get_res_count();
include $header;
?>

<div id="master">
    <div id="main-container">
        <h2>Reservations
            
        </h2>
        <br />
        <div id="nav-container-left">
            <!-- display a list of categories -->
            <ul>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
            </ul>
        </div>

        <div id="content">
            <p><a href="reservation_list.php">Current Reservations</a>: <?php echo $res_count; ?></p>

            <style type="text/css">
                body 
                {
                    background-image: url('<?php echo $reservations;?>');
                    background-size: cover;
                }
            </style>

        </div>

        <?php include $footer; ?>
