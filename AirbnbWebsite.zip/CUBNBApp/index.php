<?php
require('model/variables.php');
require('model/config.php');
require('model/cubnb_db.php');
$res_count = get_res_count();
$loc_count = get_loc_count();
$user_count = get_users();
include $header;
session_start();
?>

<div id="master">
    <div id="main-container">
        <h2>Hello & <?php echo "Welcome, " . $_SESSION['firstname'] . "!"; ?>
            <br />
            <br />
            System Status 

            <?php date_default_timezone_set('EST');
            echo date('l jS \of F Y');
            
            ?>
            
        </h2>
        <br />
        <div id="nav-container-left">
            <!-- display a list of categories -->
            <ul>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
            </ul>
        </div>

        <div id="content">
            
            <style type="text/css">
                body 
                {
                    background-image: url('<?php echo $background;?>');
                    background-size: cover;
                }
            </style>

        </div>

        <?php include $footer; ?>
